#ifndef relatorio_h
#define relatorio_h

#include "servico.h"

void relatorio_mecanico(servico servicos[],int total_servicos,const char *mecanico);
void relatorio_servico(servico servicos[],int total_servicos,const char *tipo_servico);

#endif